<?php
class SMDesign_Colorswatch_Block_Adminhtml_Welcome extends SMDesign_Colorswatch_Block_Adminhtml_Abstract {

    protected function _construct() {

    	
      parent::_construct();
			

    }
    
}