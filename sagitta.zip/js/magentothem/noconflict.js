jQuery.noConflict();
// (function ($){
    // /* plugin code */
// })(jQuery);

// var $j = jQuery.noConflict();
// $j('.content');

// if (typeof jQuery !== 'undefined') {
    // jQuery.noConflict();
// }