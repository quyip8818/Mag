<?php
class Magentothem_Categorytabsliders_Block_Categorytabsliders_Widget_Advanced
    extends Magentothem_Categorytabsliders_Block_Categorytabsliders_Advanced
    implements Mage_Widget_Block_Interface
{
    /**
     * Internal contructor
     *
     */
    protected function _construct()
    {
        
        parent::_construct();

    }
}
