<?php

class Magentothem_Categorytabsliders_Helper_Data extends Mage_Core_Helper_Abstract
{

}