<?php

class Magentothem_Bestsellerproductvertscroller_Helper_Data extends Mage_Core_Helper_Abstract
{

}