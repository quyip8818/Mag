<?php

class Magentothem_Newproductslider_Helper_Data extends Mage_Core_Helper_Abstract
{

}