<?php

class Magentothem_Prozoom_Helper_Data extends Mage_Core_Helper_Abstract
{

}