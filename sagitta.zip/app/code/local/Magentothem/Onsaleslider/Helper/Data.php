<?php

class Magentothem_Onsaleslider_Helper_Data extends Mage_Core_Helper_Abstract
{

}