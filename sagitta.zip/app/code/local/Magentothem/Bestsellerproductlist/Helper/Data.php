<?php

class Magentothem_Bestsellerproductlist_Helper_Data extends Mage_Core_Helper_Abstract
{

}