<?php
class Magentothem_Categorytabs_Block_Categorytabs_Widget_Advanced
    extends Magentothem_Categorytabs_Block_Categorytabs_Advanced
    implements Mage_Widget_Block_Interface
{
    /**
     * Internal contructor
     *
     */
    protected function _construct()
    {
        
        parent::_construct();

    }
}
