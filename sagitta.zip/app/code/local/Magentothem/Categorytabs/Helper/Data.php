<?php

class Magentothem_Categorytabs_Helper_Data extends Mage_Core_Helper_Abstract
{

}